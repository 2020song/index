const getters = {
    token: state => state.user.token,
    userName: state => state.user.userName
  }
  export default getters
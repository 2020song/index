App({
  onLaunch() {
   
  },
  globalData: {
    userInfo: null
  }
})
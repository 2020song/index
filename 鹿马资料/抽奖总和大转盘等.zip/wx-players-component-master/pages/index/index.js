const app = getApp()
Page({
  data: {
    list: [
      {
        id: 'rotate',
        sub: 'rotate',
        name: '大转盘'
      }, 
      {
        id: 'scratch',
        sub: 'scratch',
        name: '刮刮乐'
      }, 
      {
        id: 'slotmachine',
        sub: 'machine',
        name: '老虎机'
      }, 
      {
        id: 'marquee',
        sub: 'marquee',
        name: '跑马灯'
      }, 
      {
        id: 'gridcard',
        sub: 'gridcard',
        name: '九宫格翻纸牌'
      },
      {
        id: 'shake',
        sub: 'shake',
        name: '摇一摇'
      },          
      {
        id: 'gestureLock',
        sub: 'gestureLock',
        name: '手势解锁'
      }      
    ]
  },

   
})
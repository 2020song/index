# wx-players-component
微信小程序大转盘 刮刮乐 老虎机 跑马灯 九宫格 翻纸牌 摇一摇 手势解锁功能组件集合

先看效果:
![在这里插入图片描述](https://img-blog.csdnimg.cn/201908011544111.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3hpYW9kaTUyMDUyMA==,size_16,color_FFFFFF,t_70)
里面组件都进行了封装,拿来改数据即可以用,不用谢,我只是知识的搬运工.
